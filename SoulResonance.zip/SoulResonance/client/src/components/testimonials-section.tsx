import { motion } from "framer-motion";
import { Star } from "lucide-react";

export default function TestimonialsSection() {
  const testimonials = [
    {
      name: "Sarah M.",
      image: "https://images.unsplash.com/photo-1494790108755-2616b612b1c5?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
      text: "The Access Bars session was life-changing. I felt years of stress melt away and experienced a profound sense of peace I haven't felt in decades.",
    },
    {
      name: "Michael R.",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
      text: "The spiritual coaching sessions helped me break through limiting beliefs and step into my true power. I feel more aligned than ever before.",
    },
    {
      name: "Emma L.",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
      text: "The Quantum Touch healing brought incredible relief to chronic pain I'd carried for years. The energy work is truly miraculous.",
    },
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-[hsl(var(--rose-quartz-300)_/_0.1)] to-[hsl(var(--lavender-300)_/_0.1)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2
            className="text-4xl md:text-5xl font-light text-gray-800 mb-6"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            Soul <span className="text-[hsl(var(--rose-quartz-500))]">Transformations</span>
          </motion.h2>
          
          <motion.p
            className="text-xl text-gray-600 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            Hear from beautiful souls who have experienced profound shifts through our healing work.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              className="glassmorphism-dark rounded-3xl p-6 text-center"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
            >
              <div className="w-16 h-16 mx-auto mb-4 rounded-full overflow-hidden">
                <img
                  src={testimonial.image}
                  alt={`${testimonial.name} testimonial`}
                  className="w-full h-full object-cover"
                />
              </div>
              
              <p className="text-gray-600 mb-4 italic leading-relaxed">
                "{testimonial.text}"
              </p>
              
              <h4 className="font-medium text-gray-800 mb-2">{testimonial.name}</h4>
              
              <div className="flex justify-center">
                <div className="flex space-x-1 text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}