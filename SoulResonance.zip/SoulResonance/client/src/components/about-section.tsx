import { motion } from "framer-motion";
import { Tag, Hand, Brain } from "lucide-react";

export default function AboutSection() {
  return (
    <section id="about" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-light text-gray-800 mb-6">
              Meet Your <span className="text-[hsl(var(--lavender-500))]">Spiritual Guide</span>
            </h2>
            
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              With over 15 years of experience in energy healing and spiritual guidance, I help souls 
              reconnect with their authentic power through transformative practices rooted in ancient wisdom 
              and quantum consciousness.
            </p>
            
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              My journey began with a profound spiritual awakening that led me to study Access Bars, 
              Quantum Touch, and consciousness expansion techniques. Today, I guide others on their 
              path to inner peace and unlimited potential.
            </p>
            
            <div className="flex flex-wrap gap-4">
              <div className="flex items-center space-x-2">
                <Tag className="text-[hsl(var(--teal-500))] w-5 h-5" />
                <span className="text-gray-700">Certified Access Bars Practitioner</span>
              </div>
              <div className="flex items-center space-x-2">
                <Hand className="text-[hsl(var(--lavender-500))] w-5 h-5" />
                <span className="text-gray-700">Quantum Touch Healer</span>
              </div>
              <div className="flex items-center space-x-2">
                <Brain className="text-[hsl(var(--rose-quartz-500))] w-5 h-5" />
                <span className="text-gray-700">Consciousness Coach</span>
              </div>
            </div>
          </motion.div>
          
          <motion.div
            className="relative"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            viewport={{ once: true }}
          >
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=800"
                alt="Spiritual mentor in meditation pose"
                className="rounded-3xl shadow-2xl w-full max-w-md mx-auto"
              />
              
              <motion.div
                className="absolute -bottom-6 -right-6 w-24 h-24 bg-gradient-to-br from-[hsl(var(--lavender-300))] to-[hsl(var(--teal-300))] rounded-full opacity-60"
                animate={{ y: [-20, 0, -20] }}
                transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
              />
              
              <motion.div
                className="absolute -top-6 -left-6 w-16 h-16 bg-gradient-to-br from-[hsl(var(--rose-quartz-300))] to-[hsl(var(--lavender-300))] rounded-full opacity-40"
                animate={{ y: [-20, 0, -20] }}
                transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 2 }}
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}