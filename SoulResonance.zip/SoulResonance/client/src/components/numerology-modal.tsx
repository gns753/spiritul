import { useState } from "react";
import { motion } from "framer-motion";
import { X, Calculator, Sparkles, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/contexts/language-context";

interface NumerologyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface NumerologyResult {
  lifePath: number;
  destiny: number;
  soul: number;
  personality: number;
  interpretation: string;
}

export default function NumerologyModal({ isOpen, onClose }: NumerologyModalProps) {
  const [formData, setFormData] = useState({
    name: "",
    birthDate: "",
    motherName: ""
  });
  const [results, setResults] = useState<NumerologyResult | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);
  const { toast } = useToast();
  const { t } = useLanguage();

  const calculateNumerology = (name: string, birthDate: string, motherName: string): NumerologyResult => {
    const reduceNumber = (num: number): number => {
      while (num > 9 && num !== 11 && num !== 22 && num !== 33) {
        num = num.toString().split('').reduce((sum, digit) => sum + parseInt(digit), 0);
      }
      return num;
    };

    const nameValue = (str: string): number => {
      const values: Record<string, number> = {
        'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6, 'g': 7, 'h': 8, 'i': 9,
        'j': 1, 'k': 2, 'l': 3, 'm': 4, 'n': 5, 'o': 6, 'p': 7, 'q': 8, 'r': 9,
        's': 1, 't': 2, 'u': 3, 'v': 4, 'w': 5, 'x': 6, 'y': 7, 'z': 8
      };
      return str.toLowerCase().replace(/[^a-z]/g, '').split('').reduce((sum, char) => sum + (values[char] || 0), 0);
    };

    const dateSum = birthDate.replace(/-/g, '').split('').reduce((sum, digit) => sum + parseInt(digit), 0);
    const lifePath = reduceNumber(dateSum);
    const destiny = reduceNumber(nameValue(name));
    const soul = reduceNumber(nameValue(name.replace(/[bcdfghjklmnpqrstvwxyz]/gi, '')));
    const personality = reduceNumber(nameValue(name.replace(/[aeiou]/gi, '')));

    const interpretations: Record<number, string> = {
      1: "Leader, pioneer, independent - You are destined to lead and create new paths",
      2: "Diplomat, cooperative, peacemaker - Your gift is bringing harmony and balance",
      3: "Creative, communicator, optimistic - You inspire others through artistic expression",
      4: "Builder, practical, disciplined - Your strength lies in creating stable foundations",
      5: "Free spirit, adventurous, versatile - You seek freedom and new experiences",
      6: "Nurturer, responsible, healing - You are called to serve and care for others",
      7: "Seeker, spiritual, analytical - Your path involves deep wisdom and spiritual insight",
      8: "Achiever, ambitious, material mastery - You are destined for worldly success",
      9: "Humanitarian, compassionate, universal - Your mission is to serve humanity",
      11: "Spiritual messenger, intuitive, inspirational - You channel divine wisdom",
      22: "Master builder, visionary, powerful - You can manifest dreams into reality",
      33: "Master teacher, healer, compassionate - You uplift humanity through service"
    };

    return {
      lifePath,
      destiny,
      soul,
      personality,
      interpretation: interpretations[lifePath] || "Your unique path awaits discovery"
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.birthDate) {
      toast({
        title: "Missing Information",
        description: "Please enter your name and birth date",
        variant: "destructive"
      });
      return;
    }

    setIsCalculating(true);
    
    // Simulate calculation time for dramatic effect
    setTimeout(() => {
      const result = calculateNumerology(formData.name, formData.birthDate, formData.motherName);
      setResults(result);
      setIsCalculating(false);
    }, 2000);
  };

  const reset = () => {
    setFormData({ name: "", birthDate: "", motherName: "" });
    setResults(null);
  };

  if (!isOpen) return null;

  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <motion.div
        className="glassmorphism-dark rounded-3xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-purple-500/30"
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.8, opacity: 0 }}
      >
        <div className="flex justify-between items-start mb-8">
          <div className="flex items-center space-x-3">
            <Calculator className="text-[hsl(var(--cosmic-purple))] w-8 h-8 animate-pulse-slow" />
            <h2 className="text-3xl font-serif text-white">{t("numerology-calc")}</h2>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="text-gray-400 hover:text-white"
          >
            <X className="w-6 h-6" />
          </Button>
        </div>

        {!results ? (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Full Name *
              </label>
              <Input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-3 rounded-2xl bg-black/30 border border-purple-500/30 text-white placeholder-gray-400 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Enter your full name"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Birth Date *
              </label>
              <Input
                type="date"
                value={formData.birthDate}
                onChange={(e) => setFormData({ ...formData, birthDate: e.target.value })}
                className="w-full px-4 py-3 rounded-2xl bg-black/30 border border-purple-500/30 text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Mother's Name (Optional)
              </label>
              <Input
                type="text"
                value={formData.motherName}
                onChange={(e) => setFormData({ ...formData, motherName: e.target.value })}
                className="w-full px-4 py-3 rounded-2xl bg-black/30 border border-purple-500/30 text-white placeholder-gray-400 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Mother's maiden name (optional)"
              />
            </div>

            <Button
              type="submit"
              disabled={isCalculating}
              className="w-full py-4 bg-gradient-to-r from-[hsl(var(--cosmic-purple))] to-purple-600 text-white rounded-2xl font-medium transition-all duration-300 hover:scale-105"
            >
              {isCalculating ? (
                <motion.div
                  className="flex items-center justify-center space-x-3"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  <span>Calculating Cosmic Blueprint...</span>
                </motion.div>
              ) : (
                <div className="flex items-center justify-center space-x-2">
                  <Sparkles className="w-5 h-5" />
                  <span>{t("calculate")}</span>
                </div>
              )}
            </Button>
          </form>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="text-center mb-8">
              <h3 className="text-2xl font-serif text-white mb-4">Your Cosmic Blueprint</h3>
              <div className="flex justify-center space-x-8">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-[hsl(var(--cosmic-purple))] to-purple-600 rounded-full flex items-center justify-center mx-auto mb-2">
                    <span className="text-2xl font-bold text-white">{results.lifePath}</span>
                  </div>
                  <p className="text-sm text-gray-300">Life Path</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-[hsl(var(--cosmic-blue))] to-blue-600 rounded-full flex items-center justify-center mx-auto mb-2">
                    <span className="text-2xl font-bold text-white">{results.destiny}</span>
                  </div>
                  <p className="text-sm text-gray-300">Destiny</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-[hsl(var(--mystic-pink))] to-pink-600 rounded-full flex items-center justify-center mx-auto mb-2">
                    <span className="text-2xl font-bold text-white">{results.soul}</span>
                  </div>
                  <p className="text-sm text-gray-300">Soul</p>
                </div>
              </div>
            </div>

            <div className="glassmorphism rounded-2xl p-6">
              <div className="flex items-center mb-4">
                <Star className="text-yellow-400 w-5 h-5 mr-2" />
                <h4 className="text-lg font-serif text-white">Your Sacred Message</h4>
              </div>
              <p className="text-gray-300 leading-relaxed">{results.interpretation}</p>
            </div>

            <div className="flex space-x-4">
              <Button
                onClick={reset}
                className="flex-1 py-3 bg-gray-600 hover:bg-gray-700 text-white rounded-2xl transition-colors"
              >
                Calculate Again
              </Button>
              <Button
                onClick={onClose}
                className="flex-1 py-3 bg-gradient-to-r from-[hsl(var(--cosmic-purple))] to-purple-600 text-white rounded-2xl transition-all duration-300 hover:scale-105"
              >
                Complete Reading
              </Button>
            </div>
          </motion.div>
        )}
      </motion.div>
    </motion.div>
  );
}