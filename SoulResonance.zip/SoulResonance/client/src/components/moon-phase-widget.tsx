import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Moon, Sparkles } from "lucide-react";
import { useLanguage } from "@/contexts/language-context";

interface MoonPhase {
  name: string;
  emoji: string;
  message: string;
  illumination: number; // 0-1
}

export default function MoonPhaseWidget() {
  const { t, currentLanguage } = useLanguage();
  const [currentPhase, setCurrentPhase] = useState<MoonPhase | null>(null);

  const moonPhases = {
    az: {
      "new-moon": { name: "Yeni Ay", emoji: "🌑", message: "Yeni başlanğıclar və niyyətlər üçün mükəmməl vaxt" },
      "waxing-crescent": { name: "Böyüyən Aypara", emoji: "🌒", message: "Hədəflərinizi müəyyən edin və böyüməyə başlayın" },
      "first-quarter": { name: "İlk Rüb", emoji: "🌓", message: "Qərarlar verin və hərəkətə keçin" },
      "waxing-gibbous": { name: "Böyüyən Ay", emoji: "🌔", message: "Səbirlə davam edin, uğur yaxınlaşır" },
      "full-moon": { name: "Dolunay", emoji: "🌕", message: "Manifestasiya və şükür vaxtı" },
      "waning-gibbous": { name: "Azalan Ay", emoji: "🌖", message: "Minnətdarlıq və paylaşma vaxtı" },
      "last-quarter": { name: "Son Rüb", emoji: "🌗", message: "Əski şeyləri buraxın və təmizlənin" },
      "waning-crescent": { name: "Azalan Aypara", emoji: "🌘", message: "İstirahət və yenilənməyə hazırlaşın" }
    },
    tr: {
      "new-moon": { name: "Yeni Ay", emoji: "🌑", message: "Yeni başlangıçlar ve niyetler için mükemmel zaman" },
      "waxing-crescent": { name: "Büyüyen Hilal", emoji: "🌒", message: "Hedeflerinizi belirleyin ve büyümeye başlayın" },
      "first-quarter": { name: "İlk Dördün", emoji: "🌓", message: "Kararlar verin ve harekete geçin" },
      "waxing-gibbous": { name: "Büyüyen Ay", emoji: "🌔", message: "Sabırla devam edin, başarı yaklaşıyor" },
      "full-moon": { name: "Dolunay", emoji: "🌕", message: "Manifestasyon ve şükran zamanı" },
      "waning-gibbous": { name: "Küçülen Ay", emoji: "🌖", message: "Minnettarlık ve paylaşma zamanı" },
      "last-quarter": { name: "Son Dördün", emoji: "🌗", message: "Eski şeyleri bırakın ve temizlenin" },
      "waning-crescent": { name: "Küçülen Hilal", emoji: "🌘", message: "Dinlenme ve yenilenmeye hazırlanın" }
    },
    en: {
      "new-moon": { name: "New Moon", emoji: "🌑", message: "Perfect time for new beginnings and setting intentions" },
      "waxing-crescent": { name: "Waxing Crescent", emoji: "🌒", message: "Set your goals and begin to grow" },
      "first-quarter": { name: "First Quarter", emoji: "🌓", message: "Make decisions and take action" },
      "waxing-gibbous": { name: "Waxing Gibbous", emoji: "🌔", message: "Continue with patience, success is near" },
      "full-moon": { name: "Full Moon", emoji: "🌕", message: "Time for manifestation and gratitude" },
      "waning-gibbous": { name: "Waning Gibbous", emoji: "🌖", message: "Time for gratitude and sharing" },
      "last-quarter": { name: "Last Quarter", emoji: "🌗", message: "Release old things and cleanse" },
      "waning-crescent": { name: "Waning Crescent", emoji: "🌘", message: "Rest and prepare for renewal" }
    }
  };

  // Calculate current moon phase based on date
  const getMoonPhase = (): MoonPhase => {
    const now = new Date();
    const dayOfMonth = now.getDate();
    const phases = moonPhases[currentLanguage.code as keyof typeof moonPhases] || moonPhases.en;
    
    // Simplified moon phase calculation (real calculation would be more complex)
    let phaseKey: keyof typeof phases;
    let illumination: number;

    if (dayOfMonth <= 2 || dayOfMonth >= 29) {
      phaseKey = "new-moon";
      illumination = 0;
    } else if (dayOfMonth <= 6) {
      phaseKey = "waxing-crescent";
      illumination = 0.25;
    } else if (dayOfMonth <= 9) {
      phaseKey = "first-quarter";
      illumination = 0.5;
    } else if (dayOfMonth <= 13) {
      phaseKey = "waxing-gibbous";
      illumination = 0.75;
    } else if (dayOfMonth <= 16) {
      phaseKey = "full-moon";
      illumination = 1;
    } else if (dayOfMonth <= 20) {
      phaseKey = "waning-gibbous";
      illumination = 0.75;
    } else if (dayOfMonth <= 24) {
      phaseKey = "last-quarter";
      illumination = 0.5;
    } else {
      phaseKey = "waning-crescent";
      illumination = 0.25;
    }

    const phase = phases[phaseKey];
    return {
      name: phase.name,
      emoji: phase.emoji,
      message: phase.message,
      illumination
    };
  };

  useEffect(() => {
    setCurrentPhase(getMoonPhase());
  }, [currentLanguage]);

  if (!currentPhase) return null;

  return (
    <motion.div
      className="fixed bottom-6 right-6 z-40 max-w-sm"
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.8, delay: 2.5 }}
    >
      <div className="glassmorphism-dark rounded-2xl p-6 border border-blue-500/30 shadow-2xl">
        <div className="flex items-center space-x-3 mb-4">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          >
            <Moon className="text-[hsl(var(--cosmic-blue))] w-6 h-6" />
          </motion.div>
          <div>
            <h3 className="text-white font-serif text-lg">{t("moon-phase")}</h3>
            <p className="text-gray-400 text-xs">{t("today")}</p>
          </div>
        </div>
        
        <div className="text-center mb-4">
          <motion.div
            className="text-4xl mb-2"
            animate={{ 
              scale: [1, 1.1, 1],
              opacity: [0.8, 1, 0.8]
            }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            {currentPhase.emoji}
          </motion.div>
          <h4 className="text-white font-medium">{currentPhase.name}</h4>
        </div>
        
        <motion.p
          className="text-gray-300 text-sm leading-relaxed mb-4 text-center"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          {currentPhase.message}
        </motion.p>
        
        {/* Illumination indicator */}
        <div className="flex items-center justify-center space-x-2">
          <Sparkles className="text-yellow-400 w-4 h-4" />
          <div className="flex-1 h-2 bg-gray-700 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-yellow-400 to-white rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${currentPhase.illumination * 100}%` }}
              transition={{ duration: 1, delay: 0.5 }}
            />
          </div>
          <span className="text-xs text-gray-400 font-mono">
            {Math.round(currentPhase.illumination * 100)}%
          </span>
        </div>
      </div>
    </motion.div>
  );
}