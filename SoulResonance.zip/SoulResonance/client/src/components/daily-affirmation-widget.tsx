import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Heart, Sparkles, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/language-context";

export default function DailyAffirmationWidget() {
  const { t, currentLanguage } = useLanguage();
  const [currentAffirmation, setCurrentAffirmation] = useState("");

  const affirmations = {
    az: [
      "Mən sevgi və nurla doluam, bu gün gözəl fürsətlər məni gözləyir",
      "Kainatın enerjisi məni dəstəkləyir və bələdçilik edir",
      "Mən öz daxili gücümü tanıyıram və həyatımı sevgi ilə yaradıram",
      "Bu gün mənə gətirdiyi hər təcrübə üçün minnətdaram",
      "Mən daim böyüyür, öyrənir və inkişaf edirəm",
      "Mənim qəlbim hər zaman sevgi və şəfqətlə açıqdır",
      "Mən öz həqiqi məqsədimə doğru inamla irəliləyirəm"
    ],
    tr: [
      "Sevgi ve ışıkla doluyum, bugün güzel fırsatlar beni bekliyor",
      "Evrenin enerjisi bana destek olur ve rehberlik eder",
      "İçimdeki gücü tanıyor ve hayatımı sevgiyle yaratıyorum",
      "Bugün bana getirdiği her deneyim için minnettarım",
      "Sürekli büyüyor, öğreniyor ve gelişiyorum",
      "Kalbim her zaman sevgi ve şefkatle açık",
      "Gerçek amacıma doğru güvenle ilerliyorum"
    ],
    en: [
      "I am filled with love and light, beautiful opportunities await me today",
      "The universe's energy supports and guides me",
      "I recognize my inner power and create my life with love",
      "I am grateful for every experience today brings me",
      "I am constantly growing, learning, and evolving",
      "My heart is always open with love and compassion",
      "I move forward with confidence toward my true purpose"
    ]
  };

  const getRandomAffirmation = () => {
    const currentAffirmations = affirmations[currentLanguage.code as keyof typeof affirmations] || affirmations.en;
    const randomIndex = Math.floor(Math.random() * currentAffirmations.length);
    return currentAffirmations[randomIndex];
  };

  useEffect(() => {
    setCurrentAffirmation(getRandomAffirmation());
  }, [currentLanguage]);

  const refreshAffirmation = () => {
    setCurrentAffirmation(getRandomAffirmation());
  };

  return (
    <motion.div
      className="fixed bottom-6 left-6 z-40 max-w-sm"
      initial={{ opacity: 0, x: -100 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.8, delay: 2 }}
    >
      <div className="glassmorphism-dark rounded-2xl p-6 border border-pink-500/30 shadow-2xl">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Heart className="text-[hsl(var(--mystic-pink))] w-5 h-5 animate-pulse-slow" />
            <h3 className="text-white font-serif text-lg">{t("daily-affirmation")}</h3>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={refreshAffirmation}
            className="text-gray-400 hover:text-white p-2 h-auto"
          >
            <RefreshCw className="w-4 h-4" />
          </Button>
        </div>
        
        <motion.p
          key={currentAffirmation}
          className="text-gray-300 text-sm leading-relaxed mb-4"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          "{currentAffirmation}"
        </motion.p>
        
        <div className="flex items-center space-x-2">
          <Sparkles className="text-yellow-400 w-4 h-4" />
          <span className="text-xs text-gray-400 font-medium">{t("today")}</span>
        </div>
      </div>
    </motion.div>
  );
}