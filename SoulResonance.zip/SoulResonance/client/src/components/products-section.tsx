import { useState } from "react";
import { motion } from "framer-motion";
import { Gem, Droplets, Flower, Sparkles, Heart, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import ProductRequestModal from "./product-request-modal";

interface Product {
  id: string;
  name: string;
  description: string;
  image: string;
  icon: any;
  color: string;
  category: string;
}

const products: Product[] = [
  {
    id: "amethyst-crystal",
    name: "Amethyst Crystal",
    description: "High-vibration amethyst for spiritual protection and crown chakra activation. Handpicked for its clarity and energy resonance.",
    image: "https://images.unsplash.com/photo-1610557801359-e67c1a838c5b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
    icon: Gem,
    color: "lavender",
    category: "crystals"
  },
  {
    id: "sage-oil",
    name: "Sacred Sage Oil",
    description: "Organic white sage essential oil blend for cleansing rituals and energy purification. Blessed under the full moon.",
    image: "https://images.unsplash.com/photo-1608571607211-19e2dd3a0dce?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
    icon: Droplets,
    color: "teal",
    category: "oils"
  },
  {
    id: "meditation-cushion",
    name: "Lotus Meditation Cushion",
    description: "Hand-crafted meditation cushion filled with buckwheat hulls. Promotes proper posture and deeper meditation states.",
    image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
    icon: Flower,
    color: "rose-quartz",
    category: "meditation"
  },
  {
    id: "energy-spray",
    name: "Aura Cleansing Spray",
    description: "Energetically charged mist with rose quartz essence and frankincense. Perfect for space clearing and aura protection.",
    image: "https://images.unsplash.com/photo-1583400801513-9b5e60baa74e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
    icon: Sparkles,
    color: "lavender",
    category: "sprays"
  },
  {
    id: "rose-quartz",
    name: "Rose Quartz Heart",
    description: "Beautiful rose quartz carved into heart shape. Opens the heart chakra and attracts unconditional love energy.",
    image: "https://images.unsplash.com/photo-1602142103668-b9418de6e68e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
    icon: Heart,
    color: "rose-quartz",
    category: "crystals"
  },
  {
    id: "third-eye-oil",
    name: "Third Eye Awakening Oil",
    description: "Sacred blend of frankincense, sandalwood, and amethyst essence. Enhances intuition and psychic abilities.",
    image: "https://images.unsplash.com/photo-1594736797933-d0301ba6ed87?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
    icon: Eye,
    color: "teal",
    category: "oils"
  }
];

export default function ProductsSection() {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const getColorClasses = (color: string) => {
    switch (color) {
      case "lavender":
        return {
          iconBg: "from-[hsl(var(--lavender-300))] to-[hsl(var(--lavender-500))]",
          button: "bg-[hsl(var(--lavender-500))] hover:bg-[hsl(var(--lavender-600))]",
          glow: "hover:shadow-[0_0_30px_hsl(var(--lavender-300))]",
        };
      case "teal":
        return {
          iconBg: "from-[hsl(var(--teal-300))] to-[hsl(var(--teal-500))]",
          button: "bg-[hsl(var(--teal-500))] hover:bg-[hsl(var(--teal-600))]",
          glow: "hover:shadow-[0_0_30px_hsl(var(--teal-300))]",
        };
      case "rose-quartz":
        return {
          iconBg: "from-[hsl(var(--rose-quartz-300))] to-[hsl(var(--rose-quartz-500))]",
          button: "bg-[hsl(var(--rose-quartz-500))] hover:bg-[hsl(var(--rose-quartz-600))]",
          glow: "hover:shadow-[0_0_30px_hsl(var(--rose-quartz-300))]",
        };
      default:
        return {
          iconBg: "from-gray-300 to-gray-500",
          button: "bg-gray-500 hover:bg-gray-600",
          glow: "hover:shadow-[0_0_30px_hsl(var(--gray-300))]",
        };
    }
  };

  const handleRequestProduct = (product: Product) => {
    setSelectedProduct(product);
    setIsModalOpen(true);
  };

  return (
    <>
      <section id="products" className="py-20 relative overflow-hidden">
        {/* Soft gradient background */}
        <div className="absolute inset-0 bg-gradient-to-br from-[hsl(var(--lavender-300)_/_0.05)] via-[hsl(var(--teal-300)_/_0.05)] to-[hsl(var(--rose-quartz-300)_/_0.05)]"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <motion.h2
              className="text-4xl md:text-5xl font-light text-gray-800 mb-6"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              Sacred <span className="text-[hsl(var(--lavender-500))]">Items</span>
            </motion.h2>
            
            <motion.p
              className="text-xl text-gray-600 max-w-3xl mx-auto"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
            >
              Handcrafted spiritual tools and crystals to support your journey of inner transformation and energetic alignment.
            </motion.p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((product, index) => {
              const colorClasses = getColorClasses(product.color);
              const IconComponent = product.icon;
              
              return (
                <motion.div
                  key={product.id}
                  className={`glassmorphism-dark rounded-3xl p-6 transition-all duration-500 hover:scale-105 ${colorClasses.glow}`}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  whileHover={{ y: -5 }}
                >
                  <div className="relative mb-6 overflow-hidden rounded-2xl">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-48 object-cover transition-transform duration-500 hover:scale-110"
                    />
                    <div className={`absolute top-4 right-4 w-10 h-10 bg-gradient-to-br ${colorClasses.iconBg} rounded-full flex items-center justify-center`}>
                      <IconComponent className="text-white w-5 h-5" />
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="text-xl font-medium text-gray-800">{product.name}</h3>
                    
                    <p className="text-gray-600 text-sm leading-relaxed">
                      {product.description}
                    </p>
                    
                    <Button
                      onClick={() => handleRequestProduct(product)}
                      className={`w-full py-3 ${colorClasses.button} text-white rounded-full transition-all duration-300 font-medium`}
                    >
                      Request Intention
                    </Button>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      <ProductRequestModal
        product={selectedProduct}
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedProduct(null);
        }}
      />
    </>
  );
}