import { useState } from "react";
import { motion } from "framer-motion";
import { X, Heart, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

interface Product {
  id: string;
  name: string;
  description: string;
  image: string;
  icon: any;
  color: string;
  category: string;
}

interface ProductRequestModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function ProductRequestModal({ product, isOpen, onClose }: ProductRequestModalProps) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Request Sent ✨",
        description: "Your intention has been received with love. We'll connect with you soon.",
      });
      setIsSubmitting(false);
      setFormData({ name: "", email: "", message: "" });
      onClose();
    }, 1500);
  };

  if (!isOpen || !product) return null;

  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
    >
      <motion.div
        className="glassmorphism-dark rounded-3xl p-8 max-w-md w-full max-h-[90vh] overflow-y-auto"
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.8, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-start mb-6">
          <div className="flex items-center space-x-3">
            <Heart className="text-[hsl(var(--rose-quartz-500))] w-6 h-6" />
            <h2 className="text-2xl font-medium text-gray-800">Send Request</h2>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div className="mb-6">
          <div className="flex items-center space-x-4 p-4 glassmorphism rounded-2xl">
            <img
              src={product.image}
              alt={product.name}
              className="w-16 h-16 object-cover rounded-xl"
            />
            <div>
              <h3 className="font-medium text-gray-800">{product.name}</h3>
              <p className="text-sm text-gray-600">Sacred Item Request</p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Your Name
            </label>
            <Input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-3 rounded-2xl border border-gray-200 focus:ring-2 focus:ring-[hsl(var(--lavender-500))] focus:border-transparent bg-white/80"
              placeholder="Enter your name"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Email Address
            </label>
            <Input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full px-4 py-3 rounded-2xl border border-gray-200 focus:ring-2 focus:ring-[hsl(var(--lavender-500))] focus:border-transparent bg-white/80"
              placeholder="your@email.com"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Your Intention & Message
            </label>
            <Textarea
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              className="w-full px-4 py-3 rounded-2xl border border-gray-200 focus:ring-2 focus:ring-[hsl(var(--lavender-500))] focus:border-transparent bg-white/80 min-h-[120px] resize-none"
              placeholder="Share your intention and how this sacred item will support your spiritual journey..."
              required
            />
          </div>

          <Button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-4 bg-gradient-to-r from-[hsl(var(--lavender-500))] to-[hsl(var(--rose-quartz-500))] text-white rounded-2xl font-medium transition-all duration-300 hover:scale-105 btn-glow"
          >
            {isSubmitting ? (
              <motion.div
                className="flex items-center justify-center space-x-2"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                <span>Sending...</span>
              </motion.div>
            ) : (
              <div className="flex items-center justify-center space-x-2">
                <Send className="w-4 h-4" />
                <span>Send Request</span>
              </div>
            )}
          </Button>
        </form>

        <p className="text-xs text-gray-500 text-center mt-4">
          Your request will be sent directly to our spiritual mentor for personal consideration.
        </p>
      </motion.div>
    </motion.div>
  );
}