import { useState } from "react";
import { Flower2, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/language-context";
import LanguageSelector from "./language-selector";

export default function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { t } = useLanguage();

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const offsetTop = element.offsetTop - 80; // Account for fixed nav
      window.scrollTo({
        top: offsetTop,
        behavior: "smooth",
      });
    }
    setIsMenuOpen(false);
  };

  return (
    <nav className="fixed top-0 w-full z-50 glassmorphism-dark border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-2">
            <Flower2 className="text-2xl text-[hsl(var(--lavender-500))] animate-pulse-slow" />
            <span className="text-lg font-semibold text-white font-serif">SpiritualFlow</span>
          </div>
          
          <div className="hidden md:flex space-x-8">
            <button
              onClick={() => scrollToSection("home")}
              className="text-gray-300 hover:text-[hsl(var(--lavender-500))] transition-colors font-medium"
            >
              {t("home")}
            </button>
            <button
              onClick={() => scrollToSection("about")}
              className="text-gray-300 hover:text-[hsl(var(--lavender-500))] transition-colors font-medium"
            >
              {t("about")}
            </button>
            <button
              onClick={() => scrollToSection("services")}
              className="text-gray-300 hover:text-[hsl(var(--lavender-500))] transition-colors font-medium"
            >
              {t("services")}
            </button>
            <button
              onClick={() => scrollToSection("products")}
              className="text-gray-300 hover:text-[hsl(var(--lavender-500))] transition-colors font-medium"
            >
              {t("sacred-items")}
            </button>
            <button
              onClick={() => scrollToSection("spiritual-tools")}
              className="text-gray-300 hover:text-[hsl(var(--lavender-500))] transition-colors font-medium"
            >
              {t("spiritual-tools")}
            </button>
            <button
              onClick={() => scrollToSection("contact")}
              className="text-gray-300 hover:text-[hsl(var(--lavender-500))] transition-colors font-medium"
            >
              {t("contact")}
            </button>
          </div>

          <div className="flex items-center space-x-4">
            <LanguageSelector />
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden text-gray-300"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
        
        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden glassmorphism rounded-lg mt-2 p-4 space-y-2">
            <button
              onClick={() => scrollToSection("home")}
              className="block w-full text-left px-4 py-2 text-gray-700 hover:text-[hsl(var(--lavender-500))] transition-colors"
            >
              Home
            </button>
            <button
              onClick={() => scrollToSection("about")}
              className="block w-full text-left px-4 py-2 text-gray-700 hover:text-[hsl(var(--lavender-500))] transition-colors"
            >
              About
            </button>
            <button
              onClick={() => scrollToSection("services")}
              className="block w-full text-left px-4 py-2 text-gray-700 hover:text-[hsl(var(--lavender-500))] transition-colors"
            >
              Services
            </button>
            <button
              onClick={() => scrollToSection("products")}
              className="block w-full text-left px-4 py-2 text-gray-700 hover:text-[hsl(var(--lavender-500))] transition-colors"
            >
              Sacred Items
            </button>
            <button
              onClick={() => scrollToSection("seminars")}
              className="block w-full text-left px-4 py-2 text-gray-700 hover:text-[hsl(var(--lavender-500))] transition-colors"
            >
              Seminars
            </button>
            <button
              onClick={() => scrollToSection("contact")}
              className="block w-full text-left px-4 py-2 text-gray-700 hover:text-[hsl(var(--lavender-500))] transition-colors"
            >
              Contact
            </button>
          </div>
        )}
      </div>
    </nav>
  );
}