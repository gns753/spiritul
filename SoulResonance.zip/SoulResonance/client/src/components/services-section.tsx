import { motion } from "framer-motion";
import { Brain, Hand, Flower2, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ServicesSection() {
  const services = [
    {
      icon: Brain,
      title: "Access Bars",
      description: "Gentle touch therapy that releases electromagnetic charge stored in 32 points on your head, creating space for new possibilities and deeper awareness.",
      duration: "90 minutes",
      price: "$120",
      color: "lavender",
    },
    {
      icon: Hand,
      title: "Quantum Touch",
      description: "Powerful energy healing technique using breath and intention to facilitate deep healing at the cellular level, promoting natural alignment and well-being.",
      duration: "60 minutes",
      price: "$100",
      color: "teal",
    },
    {
      icon: Flower2,
      title: "Spiritual Coaching",
      description: "Personalized guidance to help you navigate your spiritual journey, overcome limiting beliefs, and step into your highest potential with clarity and confidence.",
      duration: "75 minutes",
      price: "$150",
      color: "rose-quartz",
    },
  ];

  const getColorClasses = (color: string) => {
    switch (color) {
      case "lavender":
        return {
          iconBg: "from-[hsl(var(--lavender-500))] to-[hsl(var(--lavender-600))]",
          button: "bg-[hsl(var(--lavender-500))] hover:bg-[hsl(var(--lavender-600))]",
        };
      case "teal":
        return {
          iconBg: "from-[hsl(var(--teal-500))] to-[hsl(var(--teal-600))]",
          button: "bg-[hsl(var(--teal-500))] hover:bg-[hsl(var(--teal-600))]",
        };
      case "rose-quartz":
        return {
          iconBg: "from-[hsl(var(--rose-quartz-500))] to-[hsl(var(--rose-quartz-600))]",
          button: "bg-[hsl(var(--rose-quartz-500))] hover:bg-[hsl(var(--rose-quartz-600))]",
        };
      default:
        return {
          iconBg: "from-gray-400 to-gray-600",
          button: "bg-gray-500 hover:bg-gray-600",
        };
    }
  };

  return (
    <section id="services" className="py-20 bg-gradient-to-br from-[hsl(var(--lavender-300)_/_0.1)] to-[hsl(var(--teal-300)_/_0.1)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2
            className="text-4xl md:text-5xl font-light text-gray-800 mb-6"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            Healing <span className="text-[hsl(var(--teal-500))]">Services</span>
          </motion.h2>
          
          <motion.p
            className="text-xl text-gray-600 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            Experience profound transformation through our signature healing modalities designed to 
            unlock your infinite potential and restore energetic balance.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const colorClasses = getColorClasses(service.color);
            const IconComponent = service.icon;
            
            return (
              <motion.div
                key={service.title}
                className="glassmorphism-dark rounded-3xl p-8 text-center hover:scale-105 transition-transform duration-300"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
              >
                <div className={`w-16 h-16 mx-auto mb-6 bg-gradient-to-br ${colorClasses.iconBg} rounded-full flex items-center justify-center`}>
                  <IconComponent className="text-white text-2xl w-8 h-8" />
                </div>
                
                <h3 className="text-2xl font-medium text-gray-800 mb-4">{service.title}</h3>
                
                <p className="text-gray-600 mb-6 leading-relaxed">
                  {service.description}
                </p>
                
                <div className="flex justify-center items-center space-x-2 text-[hsl(var(--teal-600))] mb-4">
                  <Clock className="w-4 h-4" />
                  <span>{service.duration}</span>
                </div>
                
                <Button
                  className={`w-full py-3 ${colorClasses.button} text-white rounded-full transition-colors btn-glow`}
                >
                  Book Session - {service.price}
                </Button>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}