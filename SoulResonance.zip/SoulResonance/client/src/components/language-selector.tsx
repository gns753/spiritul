import { useState } from "react";
import { motion } from "framer-motion";
import { ChevronDown } from "lucide-react";
import { useLanguage, languages } from "@/contexts/language-context";

export default function LanguageSelector() {
  const { currentLanguage, setLanguage } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);

  const handleLanguageChange = (language: any) => {
    setLanguage(language);
    setIsOpen(false);
  };

  return (
    <div className="relative">
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 px-3 py-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full text-gray-700 hover:bg-white/20 transition-colors"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <span className="text-sm">{currentLanguage.flag}</span>
        <span className="text-sm font-medium">{currentLanguage.code.toUpperCase()}</span>
        <ChevronDown 
          className={`w-3 h-3 transition-transform ${isOpen ? "rotate-180" : ""}`} 
        />
      </motion.button>

      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          className="absolute top-full right-0 mt-2 w-48 glassmorphism rounded-2xl p-2 shadow-lg z-50"
        >
          {languages.map((language) => (
            <motion.button
              key={language.code}
              onClick={() => handleLanguageChange(language)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left transition-colors ${
                currentLanguage.code === language.code
                  ? "bg-[hsl(var(--lavender-500)_/_0.2)] text-[hsl(var(--lavender-600))]"
                  : "hover:bg-white/20 text-gray-700"
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <span className="text-lg">{language.flag}</span>
              <div>
                <span className="text-sm font-medium">{language.name}</span>
                <span className="text-xs text-gray-500 ml-2">({language.code.toUpperCase()})</span>
              </div>
            </motion.button>
          ))}
        </motion.div>
      )}
    </div>
  );
}