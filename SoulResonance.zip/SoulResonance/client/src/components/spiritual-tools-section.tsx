import { useState } from "react";
import { motion } from "framer-motion";
import { Calculator, Clock, Heart, Moon, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/language-context";
import NumerologyModal from "./numerology-modal";
import MeditationTimer from "./meditation-timer";

export default function SpiritualToolsSection() {
  const { t } = useLanguage();
  const [numerologyOpen, setNumerologyOpen] = useState(false);
  const [meditationOpen, setMeditationOpen] = useState(false);

  const tools = [
    {
      id: "numerology",
      icon: Calculator,
      title: t("numerology-calc"),
      description: "Discover your life path, destiny number, and cosmic blueprint through sacred numerology",
      color: "cosmic-purple",
      action: () => setNumerologyOpen(true)
    },
    {
      id: "meditation",
      icon: Clock,
      title: t("meditation-timer"),
      description: "Sacred meditation sessions with cosmic soundscapes and visual guidance",
      color: "cosmic-blue", 
      action: () => setMeditationOpen(true)
    },
    {
      id: "affirmation",
      icon: Heart,
      title: t("daily-affirmation"),
      description: "Channel divine wisdom through personalized daily spiritual affirmations",
      color: "mystic-pink",
      action: () => console.log("Daily affirmation")
    },
    {
      id: "moon-phase",
      icon: Moon,
      title: t("moon-phase"),
      description: "Align with lunar cycles and cosmic rhythms for manifestation",
      color: "lavender-500",
      action: () => console.log("Moon phase tracker")
    }
  ];

  const getColorClasses = (color: string) => {
    const colorMap: Record<string, string> = {
      "cosmic-purple": "from-[hsl(var(--cosmic-purple))] to-purple-600",
      "cosmic-blue": "from-[hsl(var(--cosmic-blue))] to-blue-600", 
      "mystic-pink": "from-[hsl(var(--mystic-pink))] to-pink-600",
      "lavender-500": "from-[hsl(var(--lavender-500))] to-purple-500"
    };
    return colorMap[color] || "from-gray-500 to-gray-600";
  };

  return (
    <>
      <section id="spiritual-tools" className="py-20 relative overflow-hidden">
        {/* Mystical background */}
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080"
            alt="Mystical forest with divine light"
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-purple-900/30 via-blue-900/20 to-indigo-900/30"></div>
        </div>

        {/* Floating particles */}
        <div className="absolute inset-0 z-10">
          {[...Array(8)].map((_, i) => (
            <motion.div
              key={i}
              className={`absolute w-2 h-2 bg-white/60 rounded-full ${i % 2 === 0 ? 'animate-pulse-slow' : 'animate-float'}`}
              style={{
                left: `${10 + (i * 12)}%`,
                top: `${20 + (i % 3) * 25}%`,
                animationDelay: `${i * 0.5}s`
              }}
            />
          ))}
        </div>

        <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <motion.div
              className="flex items-center justify-center mb-6"
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1 }}
              viewport={{ once: true }}
            >
              <Sparkles className="text-[hsl(var(--lavender-500))] w-8 h-8 mr-3 animate-glow" />
              <h2 className="text-4xl md:text-5xl font-light text-white">
                {t("spiritual-tools")}
              </h2>
              <Sparkles className="text-[hsl(var(--teal-500))] w-8 h-8 ml-3 animate-glow" />
            </motion.div>
            
            <motion.p
              className="text-xl text-gray-300 max-w-3xl mx-auto"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
            >
              Interactive cosmic tools to guide your spiritual journey and enhance divine connection
            </motion.p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {tools.map((tool, index) => {
              const IconComponent = tool.icon;
              const colorClass = getColorClasses(tool.color);
              
              return (
                <motion.div
                  key={tool.id}
                  className="glassmorphism-dark rounded-3xl p-6 text-center hover:scale-105 transition-all duration-500 cursor-pointer group"
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  onClick={tool.action}
                  whileHover={{ y: -8 }}
                >
                  <div className={`w-16 h-16 mx-auto mb-6 bg-gradient-to-br ${colorClass} rounded-full flex items-center justify-center group-hover:animate-pulse-slow`}>
                    <IconComponent className="text-white w-8 h-8" />
                  </div>
                  
                  <h3 className="text-xl font-medium text-white mb-4 font-serif">{tool.title}</h3>
                  
                  <p className="text-gray-300 text-sm leading-relaxed mb-6">
                    {tool.description}
                  </p>
                  
                  <Button
                    onClick={(e) => {
                      e.stopPropagation();
                      tool.action();
                    }}
                    className={`w-full py-3 bg-gradient-to-r ${colorClass} text-white rounded-2xl font-medium transition-all duration-300 hover:scale-105`}
                  >
                    Open Tool
                  </Button>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      <NumerologyModal isOpen={numerologyOpen} onClose={() => setNumerologyOpen(false)} />
      <MeditationTimer isOpen={meditationOpen} onClose={() => setMeditationOpen(false)} />
    </>
  );
}