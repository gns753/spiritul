import { motion } from "framer-motion";
import { Flower2, Mail, Phone, MapPin } from "lucide-react";
import { SiInstagram, SiFacebook, SiYoutube, SiLinkedin } from "react-icons/si";

export default function FooterSection() {
  const socialLinks = [
    { icon: SiInstagram, label: "Instagram", color: "lavender" },
    { icon: SiFacebook, label: "Facebook", color: "teal" },
    { icon: SiYoutube, label: "YouTube", color: "rose-quartz" },
    { icon: SiLinkedin, label: "LinkedIn", color: "lavender" },
  ];

  const getSocialColorClasses = (color: string) => {
    switch (color) {
      case "lavender":
        return "bg-[hsl(var(--lavender-500)_/_0.2)] hover:bg-[hsl(var(--lavender-500)_/_0.4)] text-[hsl(var(--lavender-300))]";
      case "teal":
        return "bg-[hsl(var(--teal-500)_/_0.2)] hover:bg-[hsl(var(--teal-500)_/_0.4)] text-[hsl(var(--teal-300))]";
      case "rose-quartz":
        return "bg-[hsl(var(--rose-quartz-500)_/_0.2)] hover:bg-[hsl(var(--rose-quartz-500)_/_0.4)] text-[hsl(var(--rose-quartz-300))]";
      default:
        return "bg-gray-500/20 hover:bg-gray-500/40 text-gray-300";
    }
  };

  return (
    <footer id="contact" className="relative py-16 overflow-hidden">
      {/* Chakra energy background */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1582738411706-bfc8e691d1c2?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=800"
          alt="Chakra energy healing colors"
          className="w-full h-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900/60 to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-3 gap-12">
          {/* Brand */}
          <motion.div
            className="text-center md:text-left"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="flex items-center justify-center md:justify-start space-x-2 mb-4">
              <Flower2 className="text-3xl text-[hsl(var(--lavender-300))]" />
              <span className="text-2xl font-semibold text-white">SpiritualFlow</span>
            </div>
            <p className="text-gray-300 leading-relaxed">
              Guiding souls to their highest potential through ancient wisdom and quantum healing modalities.
            </p>
          </motion.div>

          {/* Contact Info */}
          <motion.div
            className="text-center"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h3 className="text-xl font-medium text-white mb-4">Connect With Us</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-center space-x-3">
                <Mail className="text-[hsl(var(--teal-300))] w-5 h-5" />
                <span className="text-gray-300">hello@spiritualflow.com</span>
              </div>
              <div className="flex items-center justify-center space-x-3">
                <Phone className="text-[hsl(var(--teal-300))] w-5 h-5" />
                <span className="text-gray-300">(555) 123-4567</span>
              </div>
              <div className="flex items-center justify-center space-x-3">
                <MapPin className="text-[hsl(var(--teal-300))] w-5 h-5" />
                <span className="text-gray-300">Sacred Space Studio, CA</span>
              </div>
            </div>
          </motion.div>

          {/* Social Links */}
          <motion.div
            className="text-center md:text-right"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            viewport={{ once: true }}
          >
            <h3 className="text-xl font-medium text-white mb-4">Follow the Journey</h3>
            <div className="flex justify-center md:justify-end space-x-4">
              {socialLinks.map((social, index) => {
                const IconComponent = social.icon;
                const colorClasses = getSocialColorClasses(social.color);
                
                return (
                  <motion.a
                    key={social.label}
                    href="#"
                    className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${colorClasses}`}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    initial={{ opacity: 0, scale: 0 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.5, delay: 0.6 + index * 0.1 }}
                    viewport={{ once: true }}
                  >
                    <IconComponent className="text-xl" />
                  </motion.a>
                );
              })}
            </div>
          </motion.div>
        </div>

        {/* Bottom Bar */}
        <motion.div
          className="mt-12 pt-8 border-t border-white/20 text-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          viewport={{ once: true }}
        >
          <p className="text-gray-400">
            © 2024 SpiritualFlow. All rights reserved. | Healing happens in sacred space.
          </p>
        </motion.div>
      </div>
    </footer>
  );
}