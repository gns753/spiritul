import { motion } from "framer-motion";
import { Calendar, Clock, Users, Waves, Expand, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function SeminarsSection() {
  const seminars = [
    {
      icon: Waves,
      title: "Quantum Flow Session",
      description: "Group energy healing experience combining breath work, meditation, and quantum field activation",
      date: "Saturday, March 18th",
      time: "2:00 PM - 5:00 PM",
      participants: "Limited to 12 participants",
      price: "$85",
      color: "lavender",
    },
    {
      icon: Expand,
      title: "Consciousness Expansion Workshop",
      description: "2-day intensive journey into higher states of awareness and spiritual awakening",
      date: "April 8-9, 2024",
      time: "9:00 AM - 6:00 PM",
      participants: "Limited to 8 participants",
      price: "$295",
      color: "teal",
    },
  ];

  const getColorClasses = (color: string) => {
    switch (color) {
      case "lavender":
        return {
          iconBg: "from-[hsl(var(--lavender-500))] to-[hsl(var(--lavender-600))]",
          button: "bg-[hsl(var(--lavender-500))] hover:bg-[hsl(var(--lavender-600))]",
        };
      case "teal":
        return {
          iconBg: "from-[hsl(var(--teal-500))] to-[hsl(var(--teal-600))]",
          button: "bg-[hsl(var(--teal-500))] hover:bg-[hsl(var(--teal-600))]",
        };
      default:
        return {
          iconBg: "from-gray-400 to-gray-600",
          button: "bg-gray-500 hover:bg-gray-600",
        };
    }
  };

  return (
    <section id="seminars" className="py-20 relative overflow-hidden">
      {/* Nature with light beams background */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080"
          alt="Nature landscape with divine light beams"
          className="w-full h-full object-cover opacity-20"
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2
            className="text-4xl md:text-5xl font-light text-gray-800 mb-6"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            Upcoming <span className="text-[hsl(var(--lavender-500))]">Seminars</span>
          </motion.h2>
          
          <motion.p
            className="text-xl text-gray-600 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            Join our transformative group experiences and connect with like-minded souls on the journey to higher consciousness.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {seminars.map((seminar, index) => {
            const colorClasses = getColorClasses(seminar.color);
            const IconComponent = seminar.icon;
            
            return (
              <motion.div
                key={seminar.title}
                className="glassmorphism rounded-3xl p-8"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.3 }}
                viewport={{ once: true }}
              >
                <div className="flex items-start space-x-4 mb-6">
                  <div className={`w-12 h-12 bg-gradient-to-br ${colorClasses.iconBg} rounded-full flex items-center justify-center flex-shrink-0`}>
                    <IconComponent className="text-white w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-medium text-gray-800 mb-2">{seminar.title}</h3>
                    <p className="text-gray-600">{seminar.description}</p>
                  </div>
                </div>
                
                <div className="space-y-3 mb-6">
                  <div className="flex items-center space-x-3">
                    <Calendar className="text-[hsl(var(--teal-500))] w-5 h-5" />
                    <span className="text-gray-700">{seminar.date}</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Clock className="text-[hsl(var(--teal-500))] w-5 h-5" />
                    <span className="text-gray-700">{seminar.time}</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Users className="text-[hsl(var(--teal-500))] w-5 h-5" />
                    <span className="text-gray-700">{seminar.participants}</span>
                  </div>
                </div>
                
                <Button
                  className={`w-full py-3 ${colorClasses.button} text-white rounded-full transition-colors btn-glow`}
                >
                  {seminar.title.includes("Quantum") ? "Join Session" : "Reserve Spot"} - {seminar.price}
                </Button>
              </motion.div>
            );
          })}
        </div>

        {/* Newsletter Signup */}
        <motion.div
          className="mt-12 text-center"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          viewport={{ once: true }}
        >
          <div className="glassmorphism rounded-3xl p-8 max-w-2xl mx-auto">
            <h3 className="text-2xl font-medium text-gray-800 mb-4">Stay Connected</h3>
            <p className="text-gray-600 mb-6">Receive updates about upcoming seminars, spiritual insights, and special offers</p>
            
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <Input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-3 rounded-full border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[hsl(var(--lavender-500))] bg-white/80"
              />
              <Button className="px-6 py-3 bg-[hsl(var(--rose-quartz-500))] text-white rounded-full hover:bg-[hsl(var(--rose-quartz-600))] transition-colors btn-glow">
                <Mail className="w-4 h-4 mr-2" />
                Subscribe
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}