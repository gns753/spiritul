import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Sparkles, Star } from "lucide-react";
import { useLanguage } from "@/contexts/language-context";

export default function HeroSection() {
  const { t } = useLanguage();
  
  const scrollToServices = () => {
    const element = document.getElementById("services");
    if (element) {
      const offsetTop = element.offsetTop - 80;
      window.scrollTo({
        top: offsetTop,
        behavior: "smooth",
      });
    }
  };

  const scrollToAbout = () => {
    const element = document.getElementById("about");
    if (element) {
      const offsetTop = element.offsetTop - 80;
      window.scrollTo({
        top: offsetTop,
        behavior: "smooth",
      });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Mystical forest with divine light background */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1441974231531-c6227db76b6e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080"
          alt="Mystical forest with divine light rays"
          className="w-full h-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/50 via-blue-900/40 to-indigo-900/50"></div>
      </div>

      {/* Floating cosmic particles */}
      <div className="absolute inset-0 z-10">
        {[...Array(12)].map((_, i) => (
          <motion.div
            key={i}
            className={`absolute w-2 h-2 rounded-full ${
              i % 3 === 0 ? 'bg-[hsl(var(--lavender-500))]/70' :
              i % 3 === 1 ? 'bg-[hsl(var(--teal-500))]/70' :
              'bg-white/60'
            }`}
            style={{
              left: `${10 + (i * 7)}%`,
              top: `${15 + (i % 4) * 20}%`,
            }}
            animate={{ 
              y: [-20, 20, -20],
              opacity: [0.3, 1, 0.3],
              scale: [0.8, 1.2, 0.8]
            }}
            transition={{ 
              duration: 4 + (i % 3), 
              repeat: Infinity, 
              ease: "easeInOut",
              delay: i * 0.2
            }}
          />
        ))}
      </div>

      {/* Hero content */}
      <div className="relative z-20 text-center px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <motion.div
          className="glassmorphism-dark rounded-3xl p-8 md:p-12 border border-purple-500/20"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
        >
          <motion.div
            className="flex items-center justify-center mb-8"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
          >
            <Sparkles className="text-[hsl(var(--lavender-500))] w-8 h-8 mr-4 animate-glow" />
            <Star className="text-[hsl(var(--gold-500))] w-6 h-6 mr-2 animate-pulse-slow" />
            <Star className="text-[hsl(var(--teal-500))] w-8 h-8 animate-pulse-slow" />
            <Star className="text-[hsl(var(--gold-500))] w-6 h-6 ml-2 animate-pulse-slow" />
            <Sparkles className="text-[hsl(var(--lavender-500))] w-8 h-8 ml-4 animate-glow" />
          </motion.div>
          
          <motion.h1
            className="text-4xl md:text-6xl lg:text-7xl font-light text-white text-glow mb-6 leading-tight font-serif"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.3 }}
          >
            {t("awaken-power")}
          </motion.h1>
          
          <motion.p
            className="text-xl md:text-2xl text-white/90 mb-8 font-light max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.6 }}
          >
            {t("transform-life")}
          </motion.p>
          
          <motion.div
            className="flex flex-col sm:flex-row gap-4 justify-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.9 }}
          >
            <Button
              onClick={scrollToServices}
              className="px-8 py-4 bg-gradient-to-r from-[hsl(var(--lavender-500))] to-purple-600 text-white rounded-full font-medium transition-all duration-300 btn-glow hover:scale-105"
            >
              <Sparkles className="w-5 h-5 mr-2" />
              {t("book-session")}
            </Button>
            <Button
              onClick={scrollToAbout}
              variant="outline"
              className="px-8 py-4 glassmorphism text-white rounded-full font-medium transition-all duration-300 hover:bg-white/10 border-purple-500/40 hover:border-purple-400/60"
            >
              <Star className="w-5 h-5 mr-2" />
              {t("learn-more")}
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}