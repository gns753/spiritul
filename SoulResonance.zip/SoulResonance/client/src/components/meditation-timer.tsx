import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { X, Play, Pause, RotateCcw, Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/language-context";

interface MeditationTimerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface TimerPreset {
  duration: number;
  name: string;
  description: string;
  color: string;
}

export default function MeditationTimer({ isOpen, onClose }: MeditationTimerProps) {
  const { t } = useLanguage();
  const [selectedPreset, setSelectedPreset] = useState<TimerPreset | null>(null);
  const [timeLeft, setTimeLeft] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const presets: TimerPreset[] = [
    {
      duration: 180,
      name: "Calm Breath",
      description: "Quick centering for busy souls",
      color: "from-[hsl(var(--teal-500))] to-cyan-500"
    },
    {
      duration: 420,
      name: "Balance Flow",
      description: "Harmonize your energy centers",
      color: "from-[hsl(var(--lavender-500))] to-purple-500"
    },
    {
      duration: 900,
      name: "Deep Alignment",
      description: "Connect with cosmic consciousness",
      color: "from-[hsl(var(--cosmic-purple))] to-indigo-600"
    }
  ];

  useEffect(() => {
    if (isActive && !isPaused && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft(time => {
          if (time <= 1) {
            setIsActive(false);
            return 0;
          }
          return time - 1;
        });
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isActive, isPaused, timeLeft]);

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const startTimer = (preset: TimerPreset) => {
    setSelectedPreset(preset);
    setTimeLeft(preset.duration);
    setIsActive(true);
    setIsPaused(false);
  };

  const toggleTimer = () => {
    if (isActive && !isPaused) {
      setIsPaused(true);
    } else if (isPaused) {
      setIsPaused(false);
    }
  };

  const resetTimer = () => {
    setIsActive(false);
    setIsPaused(false);
    if (selectedPreset) {
      setTimeLeft(selectedPreset.duration);
    }
  };

  const getProgress = (): number => {
    if (!selectedPreset) return 0;
    return ((selectedPreset.duration - timeLeft) / selectedPreset.duration) * 100;
  };

  if (!isOpen) return null;

  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <motion.div
        className="glassmorphism-dark rounded-3xl p-8 max-w-lg w-full border border-teal-500/30"
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.8, opacity: 0 }}
      >
        <div className="flex justify-between items-start mb-8">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[hsl(var(--teal-500))] to-cyan-500 flex items-center justify-center animate-pulse-slow">
              <div className="w-4 h-4 rounded-full bg-white/80"></div>
            </div>
            <h2 className="text-3xl font-serif text-white">{t("meditation-timer")}</h2>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="text-gray-400 hover:text-white"
          >
            <X className="w-6 h-6" />
          </Button>
        </div>

        {!selectedPreset ? (
          <div className="space-y-4">
            <p className="text-gray-300 text-center mb-6">Choose your meditation journey</p>
            {presets.map((preset, index) => (
              <motion.button
                key={preset.name}
                onClick={() => startTimer(preset)}
                className="w-full p-6 glassmorphism rounded-2xl text-left hover:scale-105 transition-all duration-300 border border-transparent hover:border-white/20"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -2 }}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-serif text-white mb-2">{preset.name}</h3>
                    <p className="text-gray-400 text-sm mb-3">{preset.description}</p>
                    <div className={`inline-block px-3 py-1 bg-gradient-to-r ${preset.color} rounded-full text-white text-sm font-medium`}>
                      {Math.floor(preset.duration / 60)} minutes
                    </div>
                  </div>
                  <div className="w-16 h-16 rounded-full bg-gradient-to-r from-white/10 to-white/5 flex items-center justify-center">
                    <Play className="text-white w-6 h-6" />
                  </div>
                </div>
              </motion.button>
            ))}
          </div>
        ) : (
          <div className="text-center space-y-8">
            <div className="relative">
              <motion.div 
                className="w-48 h-48 mx-auto relative"
                initial={{ scale: 0.8 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.5 }}
              >
                <div className="w-40 h-40 mx-auto rounded-full border-4 border-white/20 flex items-center justify-center relative">
                  <div className="absolute inset-0 rounded-full overflow-hidden">
                    <motion.div
                      className="h-full bg-gradient-to-r from-[hsl(var(--teal-500))] to-[hsl(var(--cosmic-purple))] rounded-full"
                      initial={{ scaleY: 0 }}
                      animate={{ scaleY: getProgress() / 100 }}
                      transition={{ duration: 0.5 }}
                      style={{ transformOrigin: 'bottom' }}
                    />
                  </div>
                  <div className="relative z-10 text-center">
                    <motion.div 
                      className="text-3xl font-mono text-white mb-1"
                      animate={{ scale: isActive && !isPaused ? [1, 1.05, 1] : 1 }}
                      transition={{ duration: 1, repeat: isActive && !isPaused ? Infinity : 0 }}
                    >
                      {formatTime(timeLeft)}
                    </motion.div>
                    <p className="text-gray-400 text-xs">{selectedPreset.name}</p>
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Breathing Guide */}
            {isActive && !isPaused && (
              <motion.div
                className="flex items-center justify-center space-x-4"
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 4, repeat: Infinity }}
              >
                <div className="w-3 h-3 rounded-full bg-white/60"></div>
                <span className="text-white text-lg font-light">Breathe deeply...</span>
                <div className="w-3 h-3 rounded-full bg-white/60"></div>
              </motion.div>
            )}

            {/* Controls */}
            <div className="flex justify-center space-x-4">
              <Button
                onClick={toggleTimer}
                className={`w-16 h-16 rounded-full bg-gradient-to-r ${selectedPreset.color} text-white hover:scale-110 transition-all duration-300 shadow-lg`}
              >
                {isActive && !isPaused ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
              </Button>
              
              <Button
                onClick={resetTimer}
                variant="ghost"
                className="w-16 h-16 rounded-full text-gray-400 hover:text-white hover:bg-white/10 transition-all duration-300"
              >
                <RotateCcw className="w-6 h-6" />
              </Button>
              
              <Button
                variant="ghost"
                className="w-16 h-16 rounded-full text-gray-400 hover:text-white hover:bg-white/10 transition-all duration-300"
              >
                <Volume2 className="w-6 h-6" />
              </Button>
            </div>

            <Button
              onClick={() => {
                setSelectedPreset(null);
                setIsActive(false);
                setIsPaused(false);
              }}
              variant="ghost"
              className="text-gray-400 hover:text-white"
            >
              Choose Different Session
            </Button>
          </div>
        )}
      </motion.div>
    </motion.div>
  );
}