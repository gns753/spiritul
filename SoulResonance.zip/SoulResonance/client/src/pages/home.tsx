import { useEffect, useState } from "react";
import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import AboutSection from "@/components/about-section";
import ServicesSection from "@/components/services-section";
import ProductsSection from "@/components/products-section";
import SpiritualToolsSection from "@/components/spiritual-tools-section";
import SeminarsSection from "@/components/seminars-section";
import TestimonialsSection from "@/components/testimonials-section";
import FooterSection from "@/components/footer-section";
import DailyAffirmationWidget from "@/components/daily-affirmation-widget";
import MoonPhaseWidget from "@/components/moon-phase-widget";
import { Button } from "@/components/ui/button";
import { ArrowUp } from "lucide-react";

export default function Home() {
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.pageYOffset > 300);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  return (
    <>
      <title>Spiritual Mentor - Awaken Your Inner Power</title>
      <meta
        name="description"
        content="Transform your life through quantum healing, spiritual awakening, and conscious expansion. Expert spiritual mentor offering Access Bars, Quantum Touch, and consciousness coaching."
      />
      
      <Navigation />
      <HeroSection />
      <AboutSection />
      <ServicesSection />
      <ProductsSection />
      <SpiritualToolsSection />
      <SeminarsSection />
      <TestimonialsSection />
      <FooterSection />
      <DailyAffirmationWidget />
      <MoonPhaseWidget />

      {/* Scroll to top button */}
      <Button
        onClick={scrollToTop}
        className={`fixed bottom-8 right-8 w-12 h-12 rounded-full shadow-lg z-50 btn-glow bg-[hsl(var(--lavender-500))] hover:bg-[hsl(var(--lavender-600))] text-white transition-all duration-300 ${
          showScrollTop ? "opacity-100 visible" : "opacity-0 invisible"
        }`}
        size="icon"
      >
        <ArrowUp className="h-4 w-4" />
      </Button>
    </>
  );
}
