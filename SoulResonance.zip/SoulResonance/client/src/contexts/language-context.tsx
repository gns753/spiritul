import { createContext, useContext, useState, ReactNode } from "react";

interface Language {
  code: string;
  name: string;
  flag: string;
}

interface LanguageContextType {
  currentLanguage: Language;
  setLanguage: (language: Language) => void;
  t: (key: string) => string;
}

const languages: Language[] = [
  { code: "az", name: "Azərbaycan", flag: "🇦🇿" },
  { code: "tr", name: "Türkçe", flag: "🇹🇷" },
  { code: "en", name: "English", flag: "🇺🇸" },
];

// Comprehensive translations for dark spiritual theme
const translations: Record<string, Record<string, string>> = {
  az: {
    home: "Ana Səhifə",
    about: "Haqqımızda", 
    services: "Xidmətlər",
    "sacred-items": "Müqəddəs Əşyalar",
    "spiritual-tools": "Ruhani Alətlər",
    seminars: "Seminarlar",
    contact: "Əlaqə",
    "awaken-power": "Daxili Qüvvənizi Oyandırın",
    "transform-life": "Kvant şəfa, mənəvi oyanış və şüurlu genişlənmə ilə həyatınızı dəyişin",
    "book-session": "Seansınızı Sifariş Verin",
    "learn-more": "Daha Çox Öyrənin",
    "numerology-calc": "Numerologiya Kalkulyatoru",
    "meditation-timer": "Meditasiya Saatı",
    "daily-affirmation": "Gündəlik Təsdiq",
    "moon-phase": "Ay Fazası",
    "today": "Bu gün",
    "calculate": "Hesabla",
    "start-meditation": "Meditasiyanı Başla",
    "cosmic-guidance": "Kosmik Rəhbərlik",
    "spiritual-journey": "Ruhani Səyahət"
  },
  tr: {
    home: "Ana Sayfa",
    about: "Hakkımızda",
    services: "Hizmetler", 
    "sacred-items": "Kutsal Eşyalar",
    "spiritual-tools": "Ruhani Araçlar",
    seminars: "Seminerler",
    contact: "İletişim",
    "awaken-power": "İç Gücünüzü Uyandırın",
    "transform-life": "Kuantum şifa, ruhsal uyanış ve bilinçli genişleme yoluyla hayatınızı dönüştürün",
    "book-session": "Seansınızı Rezerve Edin",
    "learn-more": "Daha Fazla Öğrenin",
    "numerology-calc": "Numeroloji Hesaplayıcısı",
    "meditation-timer": "Meditasyon Zamanlayıcısı", 
    "daily-affirmation": "Günlük Olumlamalar",
    "moon-phase": "Ay Evresi",
    "today": "Bugün",
    "calculate": "Hesapla",
    "start-meditation": "Meditasyonu Başlat",
    "cosmic-guidance": "Kozmik Rehberlik",
    "spiritual-journey": "Ruhani Yolculuk"
  },
  en: {
    home: "Home",
    about: "About",
    services: "Services",
    "sacred-items": "Sacred Items", 
    "spiritual-tools": "Spiritual Tools",
    seminars: "Seminars",
    contact: "Contact",
    "awaken-power": "Awaken Your Inner Power",
    "transform-life": "Transform your life through quantum healing, spiritual awakening, and conscious expansion",
    "book-session": "Book Your Session",
    "learn-more": "Learn More",
    "numerology-calc": "Numerology Calculator",
    "meditation-timer": "Meditation Timer",
    "daily-affirmation": "Daily Affirmation", 
    "moon-phase": "Moon Phase",
    "today": "Today",
    "calculate": "Calculate",
    "start-meditation": "Start Meditation",
    "cosmic-guidance": "Cosmic Guidance",
    "spiritual-journey": "Spiritual Journey"
  },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [currentLanguage, setCurrentLanguage] = useState<Language>(languages[0]);

  const setLanguage = (language: Language) => {
    setCurrentLanguage(language);
  };

  const t = (key: string): string => {
    return translations[currentLanguage.code]?.[key] || key;
  };

  return (
    <LanguageContext.Provider value={{ currentLanguage, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}

export { languages };