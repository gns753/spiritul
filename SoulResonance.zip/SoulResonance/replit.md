# Replit.md

## Overview

This is a full-stack web application built with a React frontend and Express.js backend, featuring a spiritual wellness website called "SpiritualFlow". The application is designed as a comprehensive platform for a spiritual mentor offering various healing services like Access Bars, Quantum Touch, and spiritual coaching, plus a non-commercial product showcase for spiritual items. The architecture follows a modern monorepo structure with TypeScript throughout and includes multi-language support.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **Styling**: Tailwind CSS with custom spiritual color palette (lavender, teal, rose-quartz)
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **State Management**: TanStack React Query for server state
- **Animations**: Framer Motion for smooth transitions and interactions
- **Build Tool**: Vite with custom configuration for development and production

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Session Storage**: PostgreSQL-based session store using connect-pg-simple
- **API Structure**: RESTful API with `/api` prefix
- **Development**: Hot reloading with Vite integration for full-stack development

### Database Schema
- **Users Table**: Basic user structure with id, username, and password fields
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Migrations**: Managed through drizzle-kit with migrations stored in `/migrations`
- **Validation**: Zod schemas for type-safe data validation

## Key Components

### Frontend Components
- **Navigation**: Fixed header with smooth scrolling navigation and language selector
- **Hero Section**: Landing area with cosmic energy background and call-to-action
- **About Section**: Personal introduction with credentials and certifications
- **Services Section**: Three main services (Access Bars, Quantum Touch, Spiritual Coaching) with pricing
- **Products Section**: Non-commercial showcase of handmade spiritual items with request functionality
- **Seminars Section**: Workshop listings with registration functionality
- **Testimonials Section**: Client feedback with star ratings
- **Footer Section**: Contact information and social media links
- **Language Selector**: Multi-language support (EN/AZ/TR) with flag icons
- **Product Request Modal**: Form for requesting spiritual items with intention field

### Backend Components
- **Storage Interface**: Abstract storage layer with in-memory implementation for development
- **Route Registration**: Centralized route management system
- **Error Handling**: Global error handling middleware
- **Logging**: Request/response logging with performance metrics

### UI System
- **Design System**: Complete set of accessible UI components
- **Color Scheme**: Chakra-inspired color palette (lavender, teal, rose-quartz, gold, mint) with CSS custom properties
- **Responsive Design**: Mobile-first approach with breakpoint-based layouts
- **Animations**: Scroll-triggered animations, hover effects, and smooth transitions
- **Glassmorphism**: Modern glass-like effects with backdrop blur
- **Product Cards**: Soft glowing cards with hover effects for spiritual items

## Data Flow

### Development Flow
1. Vite dev server handles frontend assets and HMR
2. Express server serves API routes and handles backend logic
3. In-memory storage provides data persistence during development
4. TanStack Query manages client-side data fetching and caching

### Production Flow
1. Frontend builds to static assets served by Express
2. Database queries handled through Drizzle ORM
3. Session management through PostgreSQL store
4. API responses cached appropriately

### Database Operations
- **User Management**: Create, read, and authenticate users
- **Session Storage**: PostgreSQL-based session persistence
- **Type Safety**: Full TypeScript integration with Drizzle ORM

## External Dependencies

### Core Dependencies
- **Database**: Neon Database for serverless PostgreSQL hosting
- **UI Library**: Radix UI for accessible component primitives
- **Styling**: Tailwind CSS for utility-first styling
- **Icons**: Lucide React for consistent iconography
- **Social Icons**: React Icons for social media integration

### Development Dependencies
- **Build Tools**: Vite for fast development and optimized builds
- **TypeScript**: Full type safety across frontend and backend
- **ESBuild**: Backend bundling for production deployment

### Runtime Dependencies
- **Database Driver**: @neondatabase/serverless for edge-compatible DB access
- **ORM**: Drizzle ORM with PostgreSQL support
- **Validation**: Zod for runtime type validation
- **Date Handling**: date-fns for date manipulation
- **Animations**: Framer Motion for smooth UI animations
- **Internationalization**: React Context-based language switching with placeholder translations
- **UI Icons**: Lucide React for interface icons, React Icons for social media

## Deployment Strategy

### Build Process
1. Frontend assets built using Vite to `/dist/public`
2. Backend bundled using ESBuild to `/dist/index.js`
3. Database migrations applied using `drizzle-kit push`

### Environment Configuration
- **Development**: Uses Vite dev server with Express backend
- **Production**: Single Node.js server serving both frontend and API
- **Database**: PostgreSQL connection via DATABASE_URL environment variable

### Deployment Requirements
- **Node.js**: ES modules support required
- **Environment Variables**: DATABASE_URL for PostgreSQL connection
- **Database**: Neon Database or compatible PostgreSQL instance
- **Build Output**: Static frontend assets and bundled backend server

### Session Management
- **Storage**: PostgreSQL-based session store
- **Configuration**: Uses connect-pg-simple for production-ready session management
- **Security**: Configured for secure session handling in production environment